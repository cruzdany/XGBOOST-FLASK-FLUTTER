from flask import Flask, render_template, request
import pickle
import numpy as np

model = pickle.load(open('model1.pkl', 'rb'))

app = Flask(__name__)



@app.route('/')
def man():
    return render_template('home.html')


@app.route('/predict', methods=['POST'])
def home():
    data1 = request.form['bedrooms']
    data2 = request.form['bathrooms']
    data3 = request.form['sqft_living']
    data4 = request.form['sqft_lot']
    data5 = request.form['floors']
    data6 = request.form['waterfront']
    data7 = request.form['view']
    data8 = request.form['condition']
    data9 = request.form['grade']
    data10 = request.form['sqft_above']
    data11 = request.form['sqft_basement']
    data12 = request.form['lat']
    data13 = request.form['long']
    data14 = request.form['sqft_living15']
    data15 = request.form['sqft_lot15']
    arr = np.array([[data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, data11, data12, data13, data14, data15]])
    pred = model.predict(arr)
    return render_template('after.html', data=pred)


if __name__ == "__main__":
    app.run(debug=True)















